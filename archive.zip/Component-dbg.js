sap.ui.define(['sap/suite/ui/generic/template/lib/AppComponent'], function(AppComponent) {
    return AppComponent.extend("termanico.zraptravel1804.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
